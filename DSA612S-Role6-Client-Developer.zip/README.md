# Role 6 - Client Developer

DSA612S Assignment 1. Both clients, plus a test fixture for running the gRPC
one before the rental service is finished.

```
q1-campus-vault-client/   Ballerina CLI client for the REST library register
q2-rental-client/         Ballerina gRPC client for the rentals platform
local-test-double/        stand-in rental server, NOT for submission
INTEGRATION-NOTES.md      problems found in the server code while building these
```

Both packages declare `distribution = "2201.13.5"` to match the rest of the
group. On an older distribution, `bal build` will refuse; either
`bal dist pull 2201.13.5` from an administrator terminal, or drop the version
in `Ballerina.toml` and regenerate the gRPC stub (see below).

---

## Question 1 - the CampusVault CLI client

Drops into the repo as a replacement for `Campus_Vault/client/`. The package is
`takunda/campus_vault_client`, same as the existing one, so nothing else has to
change.

```
cd q1-campus-vault-client
bal run              # the menu
bal run -- demo      # scripted walkthrough, no typing
```

The five views the work allocation asks for are menu options 1 to 5:

| Option | View |
|---|---|
| 1 | loan or book a resource, check it back in, check dates |
| 2 | global view, every asset |
| 3 | campus view, filter by institution or by site |
| 4 | overdue dashboard, plus per-asset maintenance status |
| 5 | schedule manager, add and remove schedules |

Options 6 to 8 (asset detail, register an asset, institutions) are there
because a marker always asks to see one record in full.

### Ports

The server currently runs **four** listeners, one per service file:

| Port | Serves |
|---|---|
| 8080 | scheduling: schedules, overdue, availability, maintenance |
| 8081 | CRUD: create, read, update, delete an asset |
| 8082 | query: global list, by institution, by site, institutions |
| 8083 | work orders: components, work orders, tasks |

The client's defaults match that, so it works against the server as it stands
today. When the team merges everything onto one listener, copy
`Config.toml.example` to `Config.toml` and point all four at the same URL. No
code change.

### How loaning works

There is no loan endpoint on the server. The brief and the work allocation both
require a loan/book view, so the client composes it from three calls that do
exist:

1. `GET /assets/{tag}/schedules/availability?startDate=&endDate=`
2. `POST /assets/{tag}/schedules` with a `BOOKING` row carrying `startDate` and `endDate`
3. `PUT /assets/{tag}` with the status changed to `OCCUPIED` or `LOANED_OUT`

Checking in reverses steps 2 and 3. The hold reference printed on issue is the
schedule id, and it is what you give back at check-in.

Be ready to say this in the defence: **step 1 is advisory only.** Nothing stops
another client slipping between steps 1 and 2, because the server offers no
atomic reserve. That is a limitation of the current API, not of this client, and
it is written up in INTEGRATION-NOTES.md.

---

## Question 2 - the rentals gRPC client

Drops in as `dsa612s_Ass1/rental_client/`. Package `hanst/rental_client`.

```
cd q2-rental-client
bal run              # the console
bal run -- demo      # all eight RPCs, scripted
```

`rental_pb.bal` is the group's generated stub, copied in unchanged. Do not edit
it. If the proto changes, regenerate:

```
bal grpc --input rental.proto --output .
```

All eight RPCs are exercised, including both streaming modes:

- `create_users` is **client-side streaming**. Six profiles go up one at a
  time, `complete()` half closes the stream, and the server answers once for
  the whole batch.
- `list_available_properties` is **server-side streaming**. Rows print as they
  arrive rather than after the last one, which is the whole point of streaming
  a search result.

The demo includes the refusals as well as the happy path: zero price, backwards
dates, an unregistered guest, a double-booking, a host editing someone else's
listing, and confirming an already-emptied cart.

### Two moments worth slowing down on in the presentation

Step 14 refuses a booking that overlaps a confirmed stay. Step 15 accepts one
that *starts on the previous guest's check-out date*. Those two together show
the date windows are half open, `[check_in, check_out)`, which is the correct
model for hotel nights and the classic off-by-one in booking systems.

---

## local-test-double

The real rental service is still the generated template: all eight RPCs return
`error("... not implemented yet")`. The client cannot be demonstrated against
it.

This folder is a stand-in implementing the same `.proto` with enough behaviour
to make the client's screens meaningful: validation, date-overlap detection,
cost calculation. It is a test fixture so that a bug in the client can be told
apart from a gap in the server.

```
cd local-test-double
bal run
```

**Delete this folder before the repo is handed in**, or keep it clearly labelled.
It is not part of anyone's marks and it is not a substitute for Roles 2 to 5
finishing the real service.

---

## What was verified, and how

The Q1 client was run end to end against the group's actual `Campus_Vault`
package, not a mock: all five views, the loan flow, the overlap refusal, the
adjacent-date acceptance, check-in, and both error paths (404 on a missing
asset, 409 on a duplicate tag).

The Q2 client was run end to end against the test double, since the real
service does not answer yet. When the real one lands, the client should need
no changes, because it was written against the group's own generated stub.

The Q1 demo seeds its own data, because the register comes up empty. Running it
twice reports the duplicates and carries on rather than stopping.
