# Integration notes

Found while building the clients against the server code. Raising these is the
client developer's job: nobody else calls every endpoint in sequence.

Ordered by how badly they hurt if nobody fixes them.

---

## 1. Question 1 runs on four ports

`crud_service.bal` opens 8081, `query_service.bal` 8082, `scheduling_service.bal`
8080, `workorder_service.bal` 8083. Each declares `service /assets` on its own
listener, so the register is split across four sockets.

`archived/service.bal` is a merged version of all of them on a single 8080, and
its header calls itself the final merged service. But it sits in a subdirectory,
and Ballerina only compiles `.bal` files in the package root. **That file has
never been compiled or run.** Every one of the four service files carries a
comment saying they must be merged before submission.

Somebody needs to either move `archived/service.bal` up to the package root and
delete the four, or change the four to share one listener. Until then the client
targets all four ports, which it does today via `configurable` URLs.

Worth checking when it is merged: the merged file was written before some later
edits and may have drifted from the four live ones.

## 2. There is no loan or booking endpoint

The brief asks for loaning and booking. The work allocation gives Role 6 a
"loan/book" view. Nothing on the server issues a loan.

The closest thing is `GET /assets/{tag}/schedules/availability`, which answers
whether a window is free. The client composes loaning out of availability check,
plus a `BOOKING` schedule, plus a `PUT` to change the status.

That works, and the demo proves it, but it means:

- **The check is advisory.** Between the availability call and the schedule
  write, another client can take the same dates. There is no atomic reserve, so
  the composition is a time-of-check-to-time-of-use gap.
- **There is no borrower record.** The borrower's name lives in the schedule's
  description string. Nothing can answer "what does this student currently have
  out" without scanning every asset.

A `POST /assets/{tag}/loans` on the scheduling service, doing the check and the
write under one lock, would close both. That is Role 4's area.

## 3. Two incompatible `.proto` files

- `dsa612s_Ass1/rental_service/rental.proto` - complete, all eight RPCs, the one
  the generated stubs come from. **This is the real one.**
- `DSA612S assi one step 1/.../property_query_service/rental.proto` - only
  `search_property` and `list_available_properties`, and it defines a different
  message: `PropertyResponse` with `property_name`, where the real contract has
  `Property` with `name`. It also has a `min_price` filter the other lacks.

Two protos means two incompatible wire formats. The work allocation says Role 1
owns the contract and that it blocks all of Question 2. Whoever owns it should
delete the second one, or fold the `min_price` filter into the real one and
regenerate every stub.

## 4. The rental service is entirely unimplemented

All eight remote functions in `rentalservice_service.bal` are still the
generated template:

```ballerina
remote function add_property(AddPropertyRequest value) returns AddPropertyResponse|error {
    return error("add_property not implemented yet");
}
```

Question 2 is worth 50 marks and 25 of those are the server. This is the single
biggest outstanding item in the assignment. `local-test-double/` shows the
shape a working one takes, but it is a fixture, not a submission.

## 5. Smaller things

**No seed data anywhere in Question 1.** The register starts empty, so a fresh
`bal run` followed by the client shows nothing at all. The Q1 demo seeds itself
as a workaround, but a `seedData()` in the server would be better and would make
the marker's first impression much stronger. Note `asset_service` already calls
a `seedData()` that does not exist anywhere.

**`PUT /assets/{tag}` takes a full `Asset`.** Sending it with `schedules: []`
does not wipe the schedules, which is good, but it means the merge behaviour is
implicit. Worth a comment in `crud_service.bal` so nobody "fixes" it later.

**Distribution versions disagree.** `Campus_Vault` says `2201.13.4`, everything
else says `2201.13.5`. Pick one.

**Typo in a package name.** `asset_service/Ballerina.toml` has
`name = "asset_serive"`.

**`Institution` is keyed by `name`, not a short code.** So the campus filter is
`GET /assets/institution/Namibia%20University%20of%20Science%20and%20Technology`.
It works, and the client URL-encodes it, but a `code` field would make the URLs
and the asset records a lot easier to type in a live demo.

---

## What the server got right

Worth saying out loud, because the above is all problems:

`GET /assets/{tag}/schedules/availability` uses half-open windows. A request
starting on the day an existing booking ends comes back available. That is the
correct model and it is the thing most booking systems get wrong. Verified
against the running server:

```
booking held 2026-10-05 to 2026-10-07
  query 2026-10-06 to 2026-10-08  ->  available: false
  query 2026-10-07 to 2026-10-09  ->  available: true
```

The 404 and 409 bodies are consistent (`{"message": "..."}`) across every
service file, which is what lets the client show a real sentence instead of a
stack trace.
