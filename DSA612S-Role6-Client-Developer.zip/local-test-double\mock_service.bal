import ballerina/grpc;
import ballerina/io;
import ballerina/time;

// ============================================================================
// NOT PART OF THE SUBMISSION.
//
// This is a stand-in for the real rental service, which is still the generated
// template returning "not implemented yet" for all eight RPCs. It exists so
// the gRPC client can be built, run and demonstrated without waiting for the
// server to be finished, and so a bug in the client can be told apart from a
// gap in the server.
//
// It implements the same .proto contract with just enough behaviour to make
// the client's screens meaningful: validation, date-overlap detection and
// cost calculation. Delete this folder before the repo is handed in, or keep
// it clearly labelled as a test fixture.
// ============================================================================

listener grpc:Listener mockListener = new (9090);

map<User> people = {};
map<Property> listings = {};
map<CartLine> carts = {};
map<Booking> ledger = {};
int propertySeq = 0;
int cartSeq = 0;
int bookingSeq = 0;

type CartLine record {|
    string cart_id;
    string guest_id;
    string property_id;
    string check_in_date;
    string check_out_date;
|};

@grpc:Descriptor {value: RENTAL_DESC}
service "RentalService" on mockListener {

    remote function add_property(AddPropertyRequest value) returns AddPropertyResponse {
        lock {
            if value.host_id.trim() == "" {
                return {success: false, message: "host_id is required"};
            }
            if value.name.trim() == "" || value.location.trim() == "" {
                return {success: false, message: "name and location are required"};
            }
            if value.price_per_night <= 0.0 {
                return {success: false, message: "price_per_night must be greater than zero"};
            }
            if value.max_guests <= 0 {
                return {success: false, message: "max_guests must be at least one"};
            }

            propertySeq += 1;
            string id = string `PROP-${propertySeq}`;
            listings[id] = {
                property_id: id,
                host_id: value.host_id,
                name: value.name,
                location: value.location,
                region: value.region,
                property_type: value.property_type,
                price_per_night: value.price_per_night,
                status: AVAILABLE,
                max_guests: value.max_guests
            };
            return {success: true, property_id: id, message: "listed"};
        }
    }

    remote function create_users(stream<User, grpc:Error?> clientStream) returns CreateUsersResponse|error {
        int created = 0;
        int rejected = 0;
        check from User user in clientStream
            do {
                lock {
                    if user.user_id.trim() == "" || people.hasKey(user.user_id) || !user.email.includes("@") {
                        rejected += 1;
                    } else {
                        people[user.user_id] = user.clone();
                        created += 1;
                    }
                }
            };
        return {
            users_created: created,
            success: created > 0,
            message: string `${created} accepted, ${rejected} rejected`
        };
    }

    remote function update_property(UpdatePropertyRequest value) returns UpdatePropertyResponse {
        lock {
            Property? existing = listings[value.property_id];
            if existing is () {
                return {success: false, message: "no listing with id " + value.property_id};
            }
            if existing.host_id != value.host_id {
                return {success: false, message: value.property_id + " belongs to another host"};
            }
            if value.price_per_night <= 0.0 {
                return {success: false, message: "price_per_night must be greater than zero"};
            }

            Property updated = existing.clone();
            updated.price_per_night = value.price_per_night;
            updated.status = value.status;
            updated.max_guests = value.max_guests > 0 ? value.max_guests : existing.max_guests;
            listings[value.property_id] = updated;
            return {success: true, message: "updated", updated_property: updated.clone()};
        }
    }

    remote function remove_property(RemovePropertyRequest value) returns RemovePropertyResponse {
        lock {
            Property? existing = listings[value.property_id];
            if existing is () {
                return {success: false, message: "no listing with id " + value.property_id};
            }
            if existing.host_id != value.host_id {
                return {success: false, message: value.property_id + " belongs to another host"};
            }

            string region = existing.region;
            _ = listings.remove(value.property_id);

            Property[] remaining = [];
            foreach Property p in listings {
                if p.host_id == value.host_id && p.region == region {
                    remaining.push(p.clone());
                }
            }
            return {
                success: true,
                message: "withdrawn, here is what you still have in " + region,
                remaining_properties: remaining.clone()
            };
        }
    }

    remote function list_available_properties(ListPropertiesRequest value)
            returns stream<Property, error?>|error {
        Property[] matches = [];
        lock {
            foreach Property p in listings {
                if p.status != AVAILABLE {
                    continue;
                }
                if value.location != "" && p.location.toLowerAscii() != value.location.toLowerAscii() {
                    continue;
                }
                if value.min_price > 0.0 && p.price_per_night < value.min_price {
                    continue;
                }
                if value.max_price > 0.0 && p.price_per_night > value.max_price {
                    continue;
                }
                matches.push(p.clone());
            }
        }
        return matches.toStream();
    }

    remote function search_property(SearchPropertyRequest value) returns SearchPropertyResponse {
        lock {
            Property? found = listings[value.property_id];
            if found is () {
                return {available: false, message: "Not Available"};
            }
            if found.status != AVAILABLE {
                return {available: false, message: "Not Available", property: found.clone()};
            }
            return {available: true, message: "available", property: found.clone()};
        }
    }

    remote function book_property(BookPropertyRequest value) returns BookPropertyResponse {
        lock {
            if !people.hasKey(value.guest_id) {
                return {success: false, message: "unknown guest " + value.guest_id};
            }
            Property? property = listings[value.property_id];
            if property is () {
                return {success: false, message: "no listing with id " + value.property_id};
            }
            if !isDate(value.check_in_date) || !isDate(value.check_out_date) {
                return {success: false, message: "dates must be yyyy-MM-dd"};
            }
            if value.check_out_date <= value.check_in_date {
                return {success: false, message: "check_out_date must be after check_in_date"};
            }
            foreach Booking b in ledger {
                if b.property_id == value.property_id && b.confirmed
                    && overlaps(b.check_in_date, b.check_out_date, value.check_in_date, value.check_out_date) {
                    return {success: false, message: property.name + " is already booked for those nights"};
                }
            }

            cartSeq += 1;
            string cartId = string `CART-${cartSeq}`;
            carts[cartId] = {
                cart_id: cartId,
                guest_id: value.guest_id,
                property_id: value.property_id,
                check_in_date: value.check_in_date,
                check_out_date: value.check_out_date
            };
            int nights = nightsBetween(value.check_in_date, value.check_out_date);
            return {
                success: true,
                cart_id: cartId,
                message: "held, not yet confirmed",
                number_of_nights: nights,
                estimated_cost: <float>nights * property.price_per_night
            };
        }
    }

    remote function confirm_booking(ConfirmBookingRequest value) returns ConfirmBookingResponse {
        lock {
            CartLine? line = carts[value.cart_id];
            if line is () {
                return {success: false, message: "nothing in your cart under " + value.cart_id};
            }
            if line.guest_id != value.guest_id {
                return {success: false, message: "that cart belongs to another guest"};
            }
            Property? property = listings[line.property_id];
            if property is () {
                return {success: false, message: "that listing has been withdrawn"};
            }
            // Re-check: time passed between holding and confirming.
            foreach Booking b in ledger {
                if b.property_id == line.property_id && b.confirmed
                    && overlaps(b.check_in_date, b.check_out_date, line.check_in_date, line.check_out_date) {
                    return {success: false, message: "those nights were taken while you were deciding"};
                }
            }

            int nights = nightsBetween(line.check_in_date, line.check_out_date);
            bookingSeq += 1;
            Booking booking = {
                booking_id: string `BK-${bookingSeq}`,
                property_id: line.property_id,
                guest_id: line.guest_id,
                check_in_date: line.check_in_date,
                check_out_date: line.check_out_date,
                number_of_nights: nights,
                total_cost: <float>nights * property.price_per_night,
                confirmed: true
            };
            ledger[booking.booking_id] = booking.clone();
            _ = carts.remove(value.cart_id);
            return {success: true, message: "booking confirmed", booking: booking.clone()};
        }
    }
}

function init() {
    io:println("MOCK rental service on 9090 - test fixture, not for submission");
}

// Half open windows: a stay ending on the 5th frees the 5th for the next guest.
function overlaps(string startA, string endA, string startB, string endB) returns boolean {
    return startA < endB && startB < endA;
}

function isDate(string value) returns boolean {
    return re `\d{4}-\d{2}-\d{2}`.isFullMatch(value);
}

function nightsBetween(string checkIn, string checkOut) returns int {
    time:Utc|error a = toInstant(checkIn);
    time:Utc|error b = toInstant(checkOut);
    if a is error || b is error {
        return 0;
    }
    return <int>(time:utcDiffSeconds(b, a) / 86400);
}

function toInstant(string date) returns time:Utc|error {
    time:Civil civil = check time:civilFromString(date + "T00:00:00Z");
    return time:utcFromCivil(civil);
}
