import ballerina/io;

// Scripted run covering all eight RPCs in the contract, in an order that tells
// a story, including the calls that are meant to be refused.
//
// The service reports business outcomes inside the response (success = false,
// available = false) and keeps gRPC errors for transport failures. So a
// refusal below prints a sentence; a crashed server would abort the demo.
function runDemo() returns error? {

    heading("1. create_users - CLIENT-SIDE STREAMING");
    io:println("  pushing six profiles one at a time, then half closing the stream");
    Create_usersStreamingClient uploader = check rental->create_users();
    User[] batch = [
        {user_id: "H-01", name: "Maria Nangolo", email: "maria@kalahari-stays.na", role: HOST},
        {user_id: "H-02", name: "Petrus Amupolo", email: "petrus@swakopbeach.na", role: HOST},
        {user_id: "G-01", name: "Selma Amutenya", email: "selma@live.na", role: GUEST},
        {user_id: "G-02", name: "Tangeni Shipena", email: "tangeni@live.na", role: GUEST},
        {user_id: "G-03", name: "Johanna Iipinge", email: "johanna@live.na", role: GUEST},
        {user_id: "G-04", name: "Erastus Haufiku", email: "erastus@live.na", role: GUEST}
    ];
    foreach User user in batch {
        check uploader->sendUser(user);
    }
    check uploader->complete();
    CreateUsersResponse? summary = check uploader->receiveCreateUsersResponse();
    if summary is CreateUsersResponse {
        io:println(string `  one reply for the whole batch: ${summary.users_created} created - ${summary.message}`);
    }

    heading("2. add_property - a host lists two places");
    AddPropertyResponse first = check rental->add_property({
        host_id: "H-01",
        name: "Klein Windhoek Garden Flat",
        location: "Windhoek",
        region: "Khomas",
        property_type: APARTMENT,
        price_per_night: 850.0,
        max_guests: 3
    });
    io:println("  " + (first.success ? "listed as " + first.property_id : "refused - " + first.message));

    AddPropertyResponse second = check rental->add_property({
        host_id: "H-02",
        name: "Mole Beachfront Studio",
        location: "Swakopmund",
        region: "Erongo",
        property_type: GUESTHOUSE,
        price_per_night: 1450.0,
        max_guests: 2
    });
    io:println("  " + (second.success ? "listed as " + second.property_id : "refused - " + second.message));

    heading("3. add_property - validation refuses a free palace");
    AddPropertyResponse silly = check rental->add_property({
        host_id: "H-01",
        name: "Free Palace",
        location: "Windhoek",
        region: "Khomas",
        property_type: HOUSE,
        price_per_night: 0.0,
        max_guests: 4
    });
    io:println("  " + (silly.success ? "accepted, which is a bug" : silly.message));

    heading("4. list_available_properties - SERVER-SIDE STREAMING, everything");
    check streamListings({location: "", min_price: 0.0, max_price: 0.0});

    heading("5. list_available_properties - Swakopmund only");
    check streamListings({location: "Swakopmund", min_price: 0.0, max_price: 0.0});

    heading("6. list_available_properties - price ceiling of N$ 1000");
    check streamListings({location: "", min_price: 0.0, max_price: 1000.0});

    heading("7. search_property - one listing by id");
    SearchPropertyResponse found = check rental->search_property({property_id: second.property_id});
    io:println("  " + found.message);
    if found.available {
        printProperties([found.property]);
    }

    heading("8. search_property - an id nobody has");
    SearchPropertyResponse missing = check rental->search_property({property_id: "PROP-999"});
    io:println("  server says: " + missing.message);

    heading("9. book_property - a guest holds three nights");
    BookPropertyResponse cart = check rental->book_property({
        guest_id: "G-01",
        property_id: second.property_id,
        check_in_date: "2026-10-02",
        check_out_date: "2026-10-05"
    });
    io:println("  " + cart.message);
    if cart.success {
        io:println(string `  ${cart.cart_id}: ${cart.number_of_nights} nights, estimate ${money(cart.estimated_cost)}`);
    }

    heading("10. book_property - check out before check in");
    BookPropertyResponse backwards = check rental->book_property({
        guest_id: "G-01",
        property_id: first.property_id,
        check_in_date: "2026-10-10",
        check_out_date: "2026-10-08"
    });
    io:println("  " + backwards.message);

    heading("11. book_property - a guest id nobody registered");
    BookPropertyResponse stranger = check rental->book_property({
        guest_id: "G-99",
        property_id: first.property_id,
        check_in_date: "2026-10-02",
        check_out_date: "2026-10-04"
    });
    io:println("  " + stranger.message);

    heading("12. confirm_booking - the cart becomes a real booking");
    ConfirmBookingResponse confirmed = check rental->confirm_booking({
        guest_id: "G-01",
        cart_id: cart.cart_id
    });
    io:println("  " + confirmed.message);
    if confirmed.success {
        printBooking(confirmed.booking);
    }

    heading("13. confirm_booking again - the cart was cleared");
    ConfirmBookingResponse again = check rental->confirm_booking({
        guest_id: "G-01",
        cart_id: cart.cart_id
    });
    io:println("  " + again.message);

    heading("14. A second guest wants nights that overlap the confirmed stay");
    BookPropertyResponse clash = check rental->book_property({
        guest_id: "G-02",
        property_id: second.property_id,
        check_in_date: "2026-10-04",
        check_out_date: "2026-10-07"
    });
    io:println("  " + clash.message);

    heading("15. Starting on the previous guest's check-out day is allowed");
    BookPropertyResponse adjacent = check rental->book_property({
        guest_id: "G-02",
        property_id: second.property_id,
        check_in_date: "2026-10-05",
        check_out_date: "2026-10-07"
    });
    io:println("  " + adjacent.message);

    heading("16. update_property - the host drops the price");
    UpdatePropertyResponse updated = check rental->update_property({
        property_id: first.property_id,
        host_id: "H-01",
        price_per_night: 780.0,
        status: AVAILABLE,
        max_guests: 3
    });
    io:println("  " + updated.message);
    if updated.success {
        printProperties([updated.updated_property]);
    }

    heading("17. update_property - a host editing someone else's listing");
    UpdatePropertyResponse thief = check rental->update_property({
        property_id: first.property_id,
        host_id: "H-02",
        price_per_night: 1.0,
        status: AVAILABLE,
        max_guests: 3
    });
    io:println("  " + thief.message);

    heading("18. remove_property - withdraw one and see what is left");
    RemovePropertyResponse left = check rental->remove_property({
        host_id: "H-01",
        property_id: first.property_id
    });
    io:println("  " + left.message);
    printProperties(left.remaining_properties);

    heading("19. remove_property - withdrawing a listing you do not own");
    RemovePropertyResponse refused = check rental->remove_property({
        host_id: "H-01",
        property_id: second.property_id
    });
    io:println("  " + refused.message);

    io:println("");
    io:println("demo finished - all eight RPCs exercised");
}
