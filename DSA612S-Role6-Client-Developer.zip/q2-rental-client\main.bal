import ballerina/io;

configurable string serverUrl = "http://localhost:9090";

// One stub for the process. The generated client owns the underlying HTTP/2
// connection, so all eight RPCs are multiplexed over a single socket rather
// than opening one per call.
final RentalServiceClient rental = check new (serverUrl);

//   bal run              the console
//   bal run -- demo      scripted walkthrough of all eight RPCs
public function main(string... args) returns error? {
    if args.length() > 0 && args[0] == "demo" {
        return runDemo();
    }
    check console();
}

function console() returns error? {
    io:println("Ministry of Tourism - accommodation platform");
    io:println("talking to " + serverUrl);

    while true {
        io:println("");
        io:println("  HOST                             GUEST");
        io:println("   1 add a listing                  5 browse (server stream)");
        io:println("   2 update a listing               6 look up one listing");
        io:println("   3 remove a listing               7 put dates in the cart");
        io:println("   4 register users (client stream) 8 confirm the booking");
        io:println("   0 quit");

        match ask("choice") {
            "1" => {
                check addListing();
            }
            "2" => {
                check updateListing();
            }
            "3" => {
                check removeListing();
            }
            "4" => {
                check registerUsers();
            }
            "5" => {
                check browse();
            }
            "6" => {
                check lookup();
            }
            "7" => {
                check hold();
            }
            "8" => {
                check confirm();
            }
            "0" => {
                io:println("bye");
                return;
            }
            _ => {
                io:println("  no such option");
            }
        }
    }
}

// ---- host side -------------------------------------------------------------

function addListing() returns error? {
    AddPropertyRequest request = {
        host_id: ask("your host id"),
        name: ask("property name"),
        location: ask("town"),
        region: ask("region"),
        property_type: toPropertyType(ask("type (APARTMENT, HOUSE, GUESTHOUSE, LODGE, CAMPSITE)")),
        price_per_night: askFloat("price per night"),
        max_guests: askInt("how many guests it sleeps")
    };
    AddPropertyResponse response = check rental->add_property(request);
    io:println(response.success
        ? "  listed as " + response.property_id
        : "  refused - " + response.message);
}

function updateListing() returns error? {
    // The contract takes price, status and capacity only, so there is no need
    // to read the listing first. Any field left at its proto3 default is still
    // sent, which is why the console asks for all three rather than pretending
    // to patch just one.
    UpdatePropertyRequest request = {
        property_id: ask("property id"),
        host_id: ask("your host id"),
        price_per_night: askFloat("new price per night"),
        status: toStatus(ask("status (AVAILABLE, UNAVAILABLE, UNDER_RENOVATION)")),
        max_guests: askInt("how many it sleeps")
    };
    UpdatePropertyResponse response = check rental->update_property(request);
    io:println("  " + response.message);
    if response.success {
        printProperties([response.updated_property]);
    }
}

function removeListing() returns error? {
    RemovePropertyResponse response = check rental->remove_property({
        host_id: ask("your host id"),
        property_id: ask("property id to withdraw")
    });
    io:println("  " + response.message);
    io:println("  what you still have listed:");
    printProperties(response.remaining_properties);
}

// Client-side streaming. Profiles go up one at a time; complete() half closes
// the stream and only then does the server answer, once, for the whole batch.
function registerUsers() returns error? {
    Create_usersStreamingClient uploader = check rental->create_users();
    int sent = 0;
    while true {
        string userId = askOptional("user id (blank to finish)");
        if userId == "" {
            break;
        }
        User user = {
            user_id: userId,
            name: ask("name"),
            email: ask("email"),
            role: ask("role (HOST / GUEST)").toUpperAscii() == "HOST" ? HOST : GUEST
        };
        check uploader->sendUser(user);
        sent += 1;
    }
    check uploader->complete();

    CreateUsersResponse? summary = check uploader->receiveCreateUsersResponse();
    if summary is () {
        io:println("  the server closed the stream without answering");
        return;
    }
    io:println(string `  sent ${sent}, server created ${summary.users_created}: ${summary.message}`);
}

// ---- guest side ------------------------------------------------------------

// Server-side streaming. Rows print as they land rather than after the last
// one, which is the entire reason for streaming a search result.
function browse() returns error? {
    ListPropertiesRequest request = {
        location: askOptional("town (blank for everywhere)"),
        min_price: 0.0,
        max_price: 0.0
    };
    string floor = askOptional("least you will pay per night");
    if floor != "" {
        float|error parsed = float:fromString(floor);
        if parsed is float {
            request.min_price = parsed;
        }
    }
    string ceiling = askOptional("most you will pay per night");
    if ceiling != "" {
        float|error parsed = float:fromString(ceiling);
        if parsed is float {
            request.max_price = parsed;
        }
    }
    check streamListings(request);
}

function streamListings(ListPropertiesRequest request) returns error? {
    stream<Property, error?> results = check rental->list_available_properties(request);
    int count = 0;
    check results.forEach(function(Property p) {
        if count == 0 {
            propertyHeader();
        }
        printProperty(p);
        count += 1;
    });
    io:println(count == 0
        ? "  nothing available on those terms"
        : string `  ${count} listing(s) streamed, one message each`);
}

function lookup() returns error? {
    SearchPropertyResponse response = check rental->search_property({property_id: ask("property id")});
    io:println("  " + response.message);
    if response.available {
        printProperties([response.property]);
    }
}

function hold() returns error? {
    BookPropertyResponse response = check rental->book_property({
        guest_id: ask("your guest id"),
        property_id: ask("property id"),
        check_in_date: ask("check in (yyyy-MM-dd)"),
        check_out_date: ask("check out (yyyy-MM-dd)")
    });
    if !response.success {
        io:println("  refused - " + response.message);
        return;
    }
    io:println(string `  ${response.cart_id} holds ${response.number_of_nights} night(s), about ${money(response.estimated_cost)}`);
    io:println("  nothing is booked until you confirm");
}

function confirm() returns error? {
    ConfirmBookingResponse response = check rental->confirm_booking({
        guest_id: ask("your guest id"),
        cart_id: ask("cart id")
    });
    io:println("  " + response.message);
    if response.success {
        printBooking(response.booking);
    }
}

// ---- enum helpers ----------------------------------------------------------
//
// The generated enums are closed, so free text from the console has to be
// mapped rather than cast. An unrecognised answer falls back to the proto3
// zero value, which is what an unset field would have been anyway.

function toPropertyType(string raw) returns PropertyType {
    match raw.toUpperAscii() {
        "HOUSE" => {
            return HOUSE;
        }
        "GUESTHOUSE" => {
            return GUESTHOUSE;
        }
        "LODGE" => {
            return LODGE;
        }
        "CAMPSITE" => {
            return CAMPSITE;
        }
    }
    return APARTMENT;
}

function toStatus(string raw) returns PropertyStatus {
    match raw.toUpperAscii() {
        "UNAVAILABLE" => {
            return UNAVAILABLE;
        }
        "UNDER_RENOVATION" => {
            return UNDER_RENOVATION;
        }
    }
    return AVAILABLE;
}
