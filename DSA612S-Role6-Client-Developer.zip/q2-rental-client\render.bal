import ballerina/io;

function pad(string value, int width) returns string {
    if value.length() >= width {
        return width > 3 ? value.substring(0, width - 3) + ".. " : value.substring(0, width);
    }
    string padded = value;
    while padded.length() < width {
        padded += " ";
    }
    return padded;
}

function rule(int width) {
    string line = "";
    while line.length() < width {
        line += "-";
    }
    io:println(line);
}

function heading(string title) {
    io:println("");
    io:println("== " + title + " ==");
}

// Namibian dollars, two decimals, no thousands separator so the columns stay
// aligned when a stay runs into five figures.
function money(float amount) returns string {
    return "N$ " + amount.toFixedString(2);
}

function propertyHeader() {
    io:println(pad("ID", 10) + pad("NAME", 30) + pad("LOCATION", 16) + pad("REGION", 14)
        + pad("TYPE", 12) + pad("PER NIGHT", 14) + pad("SLEEPS", 8) + "STATUS");
    rule(112);
}

function printProperty(Property p) {
    io:println(pad(p.property_id, 10) + pad(p.name, 30) + pad(p.location, 16) + pad(p.region, 14)
        + pad(p.property_type.toString(), 12) + pad(money(p.price_per_night), 14)
        + pad(p.max_guests.toString(), 8) + p.status.toString());
}

function printProperties(Property[] properties) {
    if properties.length() == 0 {
        io:println("  (nothing matches)");
        return;
    }
    propertyHeader();
    foreach Property p in properties {
        printProperty(p);
    }
}

function printBooking(Booking b) {
    rule(60);
    io:println("  booking   : " + b.booking_id);
    io:println("  property  : " + b.property_id);
    io:println("  guest     : " + b.guest_id);
    io:println("  stay      : " + b.check_in_date + " to " + b.check_out_date);
    io:println("  nights    : " + b.number_of_nights.toString());
    io:println("  total     : " + money(b.total_cost));
    io:println("  confirmed : " + b.confirmed.toString());
    rule(60);
}

function ask(string prompt) returns string {
    return io:readln(prompt + ": ").trim();
}

function askOptional(string prompt) returns string {
    return io:readln(prompt + " (blank to skip): ").trim();
}

function askFloat(string prompt) returns float {
    float|error parsed = float:fromString(io:readln(prompt + ": ").trim());
    return parsed is float ? parsed : 0.0;
}

function askInt(string prompt) returns int {
    int|error parsed = int:fromString(io:readln(prompt + ": ").trim());
    return parsed is int ? parsed : 0;
}

// A gRPC failure arrives as a grpc:Error carrying a status. Unwrapping it here
// keeps "the server is down" clearly separate from "those dates are taken",
// which the service reports as success = false inside a normal response.
function explain(error e) returns string {
    return "call failed: " + e.message();
}
